#pragma once
#include<set>

typedef unsigned int uint;

bool inLCRORegionMode(uint target, uint left, uint right, uint mod)
{
	uint div = left / mod;
	left = left - div * mod;
	right = right - div * mod;
	if (left <= target && target < right)
	{
		return true;
	}
	else
	{
		return false;
	}
}
class moduleManager
{
public:
	static moduleManager& getInstance()
	{
		return m_instance;
	}

	bool getAllModule(std::set<uint>&);
private:
	moduleManager();
	moduleManager& operator=(const moduleManager&);
	static moduleManager m_instance;
};

class flowCtrlCounter
{
public:
	flowCtrlCounter(uint totalTPS, uint timesPerSec);
	uint getSndTimesThisLoop();

private:
	void calModuleOrder();
	void calBaseAndSecCycle();
	bool isThisModuleTurn(uint round);
	uint m_totalTPS;
	uint m_timesPerSec;

	uint m_moduleOrder;
	uint m_numbersOfModule;
	uint m_base;
	uint m_secPerCycle;
	uint m_remainder;
	uint m_currentSec;
	uint m_currentLoop;
	uint m_moduleNumber;

};